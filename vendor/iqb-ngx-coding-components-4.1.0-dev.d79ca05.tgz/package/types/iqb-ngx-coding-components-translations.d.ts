import { TranslateLoader } from '@ngx-translate/core';
import { Observable } from 'rxjs';

/** Translation trees contain nested namespaces or leaf values. */
type TranslationMap = Record<string, unknown>;
/** Preserve library defaults and recursively apply application overrides. */
declare function mergeTranslations(base: TranslationMap, overrides: TranslationMap): TranslationMap;
/** Prefer an exact locale, its base language, then the configured fallback. */
declare function selectTranslationsForLanguage(language: string, translationsByLanguage: Record<string, TranslationMap>, fallbackLanguage?: string): TranslationMap;

declare const NGX_CODING_COMPONENTS_DE_TRANSLATIONS: Record<string, unknown>;
declare class NgxCodingComponentsTranslateLoader implements TranslateLoader {
    getTranslation(): Observable<Record<string, unknown>>;
}

export { NGX_CODING_COMPONENTS_DE_TRANSLATIONS, NgxCodingComponentsTranslateLoader, mergeTranslations, selectTranslationsForLanguage };
export type { TranslationMap };
